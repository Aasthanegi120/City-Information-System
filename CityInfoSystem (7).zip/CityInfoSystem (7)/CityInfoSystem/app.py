from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_mysqldb import MySQL
from werkzeug.security import generate_password_hash
import re
from flask_bcrypt import Bcrypt
from flask import render_template
from collections import Counter
import mysql.connector
from flask import Flask, session
from flask_session import Session
from datetime import timedelta

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Change this to a strong secret key

# 🔹 Configure server-side session storage
app.config["SESSION_TYPE"] = "filesystem"
app.config["SESSION_PERMANENT"] = True
app.config["SESSION_FILE_DIR"] = "./flask_sessions"  # Store sessions in a local folder
Session(app)

def get_db_connection():
    return mysql.connector.connect(
        host="localhost",   # Change if your database is hosted elsewhere
        user="root",        # Your MySQL username
        password='AasthaNegi@0106', # Your MySQL password
        database="city_info_system"
    )

# MySQL Configuration
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'  # Change if necessary
app.config['MYSQL_PASSWORD'] = 'AasthaNegi@0106'  # Change if necessary
app.config['MYSQL_DB'] = 'city_info'
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'

mysql = MySQL(app)
bcrypt = Bcrypt(app)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/manage_city_data')
def index():
    return render_template('index.html')


# Define the secret admin registration code
ADMIN_REGISTRATION_CODE = "SECRET123"  # Change this to a strong secret key

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        role = request.form['role']
        admin_code = request.form.get('admin_code', '')

        # Validate email format
        email_regex = r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$'
        if not re.match(email_regex, email):
            flash("Invalid email format!", "danger")
            return redirect(url_for('register'))

        # Prevent duplicate email registration
        cursor = mysql.connection.cursor()
        cursor.execute("SELECT * FROM users WHERE email = %s", (email,))
        existing_user = cursor.fetchone()
        cursor.close()

        if existing_user:
            flash("Email already registered!", "danger")
            return redirect(url_for('register'))

        # Check if the user is trying to register as an admin
        if role == 'admin' and admin_code != ADMIN_REGISTRATION_CODE:
            flash("Invalid Admin Registration Code!", "danger")
            return redirect(url_for('register'))

        # Hash the password before storing it in the database
        hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')

        # Insert user into the database
        cursor = mysql.connection.cursor()
        cursor.execute("INSERT INTO users (name, email, password, role) VALUES (%s, %s, %s, %s)",
                       (name, email, hashed_password, role))
        mysql.connection.commit()
        cursor.close()

        flash("Registration successful! You can now log in.", "success")
        return redirect(url_for('login'))

    return render_template('register.html')



@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        cursor = mysql.connection.cursor()
        cursor.execute("SELECT * FROM users WHERE email = %s", (email,))
        user = cursor.fetchone()
        cursor.close()

        if user and bcrypt.check_password_hash(user['password'], password):
            session['loggedin'] = True
            session['id'] = user['id']
            session['name'] = user['name']
            session['role'] = user['role']

            flash(f'Welcome {user["name"]}! You are logged in as {user["role"]}.', 'success')

            if user['role'] == 'admin':
                return redirect(url_for('admin_dashboard'))
            else:
                return redirect(url_for('user_dashboard'))
        else:
            flash('Invalid email or password!', 'danger')

    return render_template('login.html')



@app.route('/admin/dashboard')
def admin_dashboard():
    if 'loggedin' not in session or session['role'] != 'admin':
        flash('Unauthorized access!', 'danger')
        return redirect(url_for('login'))
    return render_template('admin_dashboard.html', name=session['name'])

@app.route('/user/dashboard')
def user_dashboard():
    if 'loggedin' not in session or session['role'] != 'user':
        flash('Unauthorized access!', 'danger')
        return redirect(url_for('login'))
    return render_template('user_dashboard.html', name=session['name'])


@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))




@app.route('/admin/manage_city_data')
def manage_city_data():
    return render_template('manage_city_data.html')



@app.route('/hospital')
def hospital():
    return render_template('hospital.html')

@app.route('/addhospital', methods=['GET', 'POST'])
def add_hospital():
    if request.method == 'POST':
        name = request.form['name']
        address = request.form['address']
        phone = request.form['phone']
        specialties = request.form['specialties']

        try:
            cur = mysql.connection.cursor()
            cur.execute("INSERT INTO hospitals (name, address, phone, specialties) VALUES (%s, %s, %s, %s)", 
                        (name, address, phone, specialties))
            mysql.connection.commit()  # ✅ Ensure changes are committed immediately
            cur.close()

            flash('Hospital added successfully!', 'success')
            return redirect(url_for('hospital'))
        except Exception as e:
            mysql.connection.rollback()  # 🔴 Rollback in case of failure
            flash('Failed to add hospital. Please try again.', 'danger')
            print(e)

    return render_template('addhospital.html')

@app.route('/viewhospital')
def view_hospital():
    try:
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM hospitals")
        hospitals = cur.fetchall()
        cur.close()
        print("Fetched Hospitals:", hospitals)  # Debugging: Print data in the console
        return render_template('viewhospital.html', hospitals=hospitals)
    except Exception as e:
        print("Error Fetching Data:", e)
        return "Error loading hospitals."




@app.route('/updatehospital', methods=['GET', 'POST'])
def update_hospital():
    conn = mysql.connection
    cursor = conn.cursor()

    # Fetch all hospitals from the database
    cursor.execute("SELECT id, name FROM hospitals")
    hospitals = cursor.fetchall()

    if request.method == 'POST':
        hospital_id = request.form['hospital_id']
        name = request.form['name']
        address = request.form['address']
        phone = request.form['phone']
        specialties = request.form['specialties']

        # Update hospital details
        cursor.execute("""
            UPDATE hospitals
            SET name=%s, address=%s, phone=%s, specialties=%s
            WHERE id=%s
        """, (name, address, phone, specialties, hospital_id))

        conn.commit()
        cursor.close()
        flash("Hospital details updated successfully!", "success")
        return redirect(url_for('update_hospital'))

    cursor.close()
    return render_template('updatehospital.html', hospitals=hospitals)


@app.route('/deletehospital', methods=['GET', 'POST'])
def delete_hospital():
    try:
        cur = mysql.connection.cursor()

        if request.method == 'POST':
            hospital_id = request.form['hospital_id']

            # Ensure hospital exists before deleting
            cur.execute("SELECT * FROM hospitals WHERE id = %s", [hospital_id])
            hospital = cur.fetchone()
            if not hospital:
                flash('Error: Hospital not found.', 'danger')
            else:
                cur.execute("DELETE FROM hospitals WHERE id = %s", [hospital_id])
                mysql.connection.commit()
                flash('Hospital deleted successfully!', 'success')
                return redirect(url_for('delete_hospital'))  # Stay on the delete page

        # Fetch hospitals for dropdown
        cur.execute("SELECT id, name FROM hospitals")
        hospitals = cur.fetchall()

        print("Fetched Hospitals:", hospitals)  # Debugging: Confirm data exists

        if not hospitals:
            flash('No hospitals found in the database!', 'warning')

    except Exception as e:
        flash(f'Failed to fetch hospitals: {str(e)}', 'danger')
        print("Database Error:", e)
        hospitals = []
    finally:
        cur.close()

    return render_template('deletehospital.html', hospitals=hospitals)







@app.route('/hotel')
def hotel():
    return render_template('hotel.html')
@app.route('/addhotel', methods=['GET', 'POST'])
def add_hotel():
    if request.method == 'POST':
        name = request.form['name']
        address = request.form['address']
        phone = request.form['phone']
        classification = request.form['classification']

        try:
            cur = mysql.connection.cursor()
            cur.execute("INSERT INTO hotels (name, address, phone, classification) VALUES (%s, %s, %s, %s)", 
                        (name, address, phone, classification))
            mysql.connection.commit()
            cur.close()

            flash('Hotel added successfully!', 'success')
            return redirect(url_for('hotel'))
        except Exception as e:
            flash('Failed to add hotel. Please try again.', 'danger')
            print(e)

    return render_template('addhotel.html')

@app.route('/viewhotel')
def view_hotel():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM hotels")
    hotels = cur.fetchall()
    cur.close()
    return render_template('viewhotel.html', hotels=hotels)

@app.route('/updatehotel', methods=['GET', 'POST'])
def update_hotel():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM hotels")
    hotels = cur.fetchall()
    cur.close()

    if request.method == 'POST':
        hotel_id = request.form['hotel_id']
        name = request.form['name']
        address = request.form['address']
        phone = request.form['phone']
        classification = request.form['classification']

        try:
            cur = mysql.connection.cursor()
            cur.execute("""
                UPDATE hotels
                SET name = %s, address = %s, phone = %s, classification = %s 
                WHERE id = %s
            """, (name, address, phone, classification, hotel_id))
            mysql.connection.commit()
            cur.close()

            flash('Hotel details updated successfully!', 'success')
            return redirect(url_for('hotel'))
        except Exception as e:
            flash('Failed to update hotel. Please try again.', 'danger')
            print(e)

    return render_template('updatehotel.html', hotels=hotels)

@app.route('/deletehotel', methods=['GET', 'POST'])
def delete_hotel():
    if request.method == 'POST':
        hotel_id = request.form['hotel_id']

        try:
            cur = mysql.connection.cursor()
            cur.execute("DELETE FROM hotels WHERE id = %s", [hotel_id])
            mysql.connection.commit()
            cur.close()

            flash('Hotel deleted successfully!', 'success')
            return redirect(url_for('hotel'))
        except Exception as e:
            flash('Failed to delete hotel. Please try again.', 'danger')
            print(e)

    cur = mysql.connection.cursor()
    cur.execute("SELECT id, name FROM hotels")
    hotels = cur.fetchall()
    cur.close()

    return render_template('deletehotel.html', hotels=hotels)



@app.route('/college')
def college():
    return render_template('college.html')

@app.route('/addcollege', methods=['GET', 'POST'])
def add_college():
    if request.method == 'POST':
        name = request.form['name']
        address = request.form['address']
        phone = request.form['phone']
        classification = request.form['classification']

        try:
            cur = mysql.connection.cursor()
            cur.execute("INSERT INTO colleges (name, address, phone, classification) VALUES (%s, %s, %s, %s)", 
                        (name, address, phone, classification))
            mysql.connection.commit()
            cur.close()

            flash('College added successfully!', 'success')
            return redirect(url_for('college'))
        except Exception as e:
            flash('Failed to add college. Please try again.', 'danger')
            print(e)

    return render_template('addcollege.html')

@app.route('/viewcollege')
def view_college():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM colleges")
    colleges = cur.fetchall()
    cur.close()
    return render_template('viewcollege.html', colleges=colleges)

@app.route('/updatecollege', methods=['GET', 'POST'])
def update_college():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM colleges")
    colleges = cur.fetchall()
    cur.close()

    if request.method == 'POST':
        college_id = request.form['college_id']
        name = request.form['name']
        address = request.form['address']
        phone = request.form['phone']
        classification = request.form['classification']

        try:
            cur = mysql.connection.cursor()
            cur.execute("""
                UPDATE colleges
                SET name = %s, address = %s, phone = %s, classification = %s 
                WHERE id = %s
            """, (name, address, phone, classification, college_id))
            mysql.connection.commit()
            cur.close()

            flash('college details updated successfully!', 'success')
            return redirect(url_for('college'))
        except Exception as e:
            flash('Failed to update college. Please try again.', 'danger')
            print(e)

    return render_template('updatecollege.html', colleges=colleges)

@app.route('/deletecollege', methods=['GET', 'POST'])
def delete_college():
    if request.method == 'POST':
        college_id = request.form['college_id']

        try:
            cur = mysql.connection.cursor()
            cur.execute("DELETE FROM colleges WHERE id = %s", [college_id])
            mysql.connection.commit()
            cur.close()

            flash('college deleted successfully!', 'success')
            return redirect(url_for('college'))
        except Exception as e:
            flash('Failed to delete college. Please try again.', 'danger')
            print(e)

    cur = mysql.connection.cursor()
    cur.execute("SELECT id, name FROM colleges")
    colleges = cur.fetchall()
    cur.close()

    return render_template('deletecollege.html', colleges=colleges)



@app.route('/school')
def school():
    return render_template('school.html')

@app.route('/addschool', methods=['GET', 'POST'])
def add_school():
    if request.method == 'POST':
        name = request.form['name']
        address = request.form['address']
        phone = request.form['phone']
        classification = request.form['classification']

        try:
            cur = mysql.connection.cursor()
            cur.execute("INSERT INTO schools (name, address, phone, classification) VALUES (%s, %s, %s, %s)", 
                        (name, address, phone, classification))
            mysql.connection.commit()
            cur.close()

            flash('School added successfully!', 'success')
            return redirect(url_for('school'))
        except Exception as e:
            flash('Failed to add school. Please try again.', 'danger')
            print(e)

    return render_template('addschool.html')

@app.route('/viewschool')
def view_school():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM schools")
    schools = cur.fetchall()
    cur.close()
    return render_template('viewschool.html', schools=schools)

@app.route('/updateschool', methods=['GET', 'POST'])
def update_school():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM schools")
    schools = cur.fetchall()
    cur.close()

    if request.method == 'POST':
        school_id = request.form['school_id']
        name = request.form['name']
        address = request.form['address']
        phone = request.form['phone']
        classification = request.form['classification']

        try:
            cur = mysql.connection.cursor()
            cur.execute("""
                UPDATE schools
                SET name = %s, address = %s, phone = %s, classification = %s 
                WHERE id = %s
            """, (name, address, phone, classification, school_id))
            mysql.connection.commit()
            cur.close()

            flash('school details updated successfully!', 'success')
            return redirect(url_for('school'))
        except Exception as e:
            flash('Failed to update school. Please try again.', 'danger')
            print(e)

    return render_template('updateschool.html', schools=schools)

@app.route('/deleteschool', methods=['GET', 'POST'])
def delete_school():
    if request.method == 'POST':
        school_id = request.form['school_id']

        try:
            cur = mysql.connection.cursor()
            cur.execute("DELETE FROM schools WHERE id = %s", [school_id])
            mysql.connection.commit()
            cur.close()

            flash('school deleted successfully!', 'success')
            return redirect(url_for('school'))
        except Exception as e:
            flash('Failed to delete school. Please try again.', 'danger')
            print(e)

    cur = mysql.connection.cursor()
    cur.execute("SELECT id, name FROM schools")
    schools = cur.fetchall()
    cur.close()

    return render_template('deleteschool.html', schools=schools)






@app.route('/theater')
def theater():
    return render_template('theater.html')

@app.route('/addtheater', methods=['GET', 'POST'])
def add_theater():
    if request.method == 'POST':
        name = request.form['name']
        address = request.form['address']
        phone = request.form['phone']
        classification = request.form['classification']

        try:
            cur = mysql.connection.cursor()
            cur.execute("INSERT INTO theaters (name, address, phone, classification) VALUES (%s, %s, %s, %s)", 
                        (name, address, phone, classification))
            mysql.connection.commit()
            cur.close()

            flash('Theater added successfully!', 'success')
            return redirect(url_for('theater'))
        except Exception as e:
            flash('Failed to add theater. Please try again.', 'danger')
            print(e)

    return render_template('addtheater.html')

@app.route('/viewtheater')
def view_theater():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM theaters")
    theaters = cur.fetchall()
    cur.close()
    return render_template('viewtheater.html', theaters=theaters)

@app.route('/updatetheater', methods=['GET', 'POST'])
def update_theater():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM theaters")
    theaters = cur.fetchall()
    cur.close()

    if request.method == 'POST':
        theater_id = request.form['theater_id']
        name = request.form['name']
        address = request.form['address']
        phone = request.form['phone']
        classification = request.form['classification']

        try:
            cur = mysql.connection.cursor()
            cur.execute("""
                UPDATE theaters
                SET name = %s, address = %s, phone = %s, classification = %s 
                WHERE id = %s
            """, (name, address, phone, classification, theater_id))
            mysql.connection.commit()
            cur.close()

            flash('theater details updated successfully!', 'success')
            return redirect(url_for('theater'))
        except Exception as e:
            flash('Failed to update theater. Please try again.', 'danger')
            print(e)

    return render_template('updatetheater.html', theaters=theaters)

@app.route('/deletetheater', methods=['GET', 'POST'])
def delete_theater():
    if request.method == 'POST':
        theater_id = request.form['theater_id']

        try:
            cur = mysql.connection.cursor()
            cur.execute("DELETE FROM theaters WHERE id = %s", [theater_id])
            mysql.connection.commit()
            cur.close()

            flash('theater deleted successfully!', 'success')
            return redirect(url_for('theater'))
        except Exception as e:
            flash('Failed to delete theater. Please try again.', 'danger')
            print(e)

    cur = mysql.connection.cursor()
    cur.execute("SELECT id, name FROM theaters")
    theaters = cur.fetchall()
    cur.close()

    return render_template('deletetheater.html', theaters=theaters)






@app.route('/mall')
def mall():
    return render_template('mall.html')

@app.route('/addmall', methods=['GET', 'POST'])
def add_mall():
    if request.method == 'POST':
        name = request.form['name']
        address = request.form['address']
        phone = request.form['phone']
        classification = request.form['classification']

        try:
            cur = mysql.connection.cursor()
            cur.execute("INSERT INTO malls (name, address, phone, classification) VALUES (%s, %s, %s, %s)", 
                        (name, address, phone, classification))
            mysql.connection.commit()
            cur.close()

            flash('Mall added successfully!', 'success')
            return redirect(url_for('mall'))
        except Exception as e:
            flash('Failed to add mall. Please try again.', 'danger')
            print(e)

    return render_template('addmall.html')

@app.route('/viewmall')
def view_mall():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM malls")
    malls = cur.fetchall()
    cur.close()
    return render_template('viewmall.html', malls=malls)

@app.route('/updatemall', methods=['GET', 'POST'])
def update_mall():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM malls")
    malls = cur.fetchall()
    cur.close()

    if request.method == 'POST':
        mall_id = request.form['mall_id']
        name = request.form['name']
        address = request.form['address']
        phone = request.form['phone']
        classification = request.form['classification']

        try:
            cur = mysql.connection.cursor()
            cur.execute("""
                UPDATE malls
                SET name = %s, address = %s, phone = %s, classification = %s 
                WHERE id = %s
            """, (name, address, phone, classification, mall_id))
            mysql.connection.commit()
            cur.close()

            flash('mall details updated successfully!', 'success')
            return redirect(url_for('theater'))
        except Exception as e:
            flash('Failed to update mall. Please try again.', 'danger')
            print(e)

    return render_template('updatemall.html', malls=malls)

@app.route('/deletemall', methods=['GET', 'POST'])
def delete_mall():
    if request.method == 'POST':
        mall_id = request.form['mall_id']

        try:
            cur = mysql.connection.cursor()
            cur.execute("DELETE FROM malls WHERE id = %s", [mall_id])
            mysql.connection.commit()
            cur.close()

            flash('Mall deleted successfully!', 'success')
            return redirect(url_for('mall'))
        except Exception as e:
            flash('Failed to delete mall. Please try again.', 'danger')
            print(e)

    cur = mysql.connection.cursor()
    cur.execute("SELECT id, name FROM malls")
    malls = cur.fetchall()
    cur.close()

    return render_template('deletemall.html', malls=malls)



@app.route('/view_hospital_user')
def view_hospital_user():
    try:
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM hospitals")
        hospitals = cur.fetchall()
        cur.close()
        print("Fetched Hospitals:", hospitals)  # Debugging: Print data in the console
        return render_template('viewhospital_user.html', hospitals=hospitals)
    except Exception as e:
        print("Error Fetching Data:", e)
        return "Error loading hospitals."
    
@app.route('/view_hotel_user')
def view_hotel_user():
    try:
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM hotels")
        hotels = cur.fetchall()
        cur.close()
        print("Fetched Hotels:", hotels)  # Debugging: Print data in the console
        return render_template('viewhotel_user.html', hotels=hotels)
    except Exception as e:
        print("Error Fetching Data:", e)
        return "Error loading hotels."


@app.route('/view_theater_user')
def view_theater_user():
    try:
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM theaters")
        theaters = cur.fetchall()
        cur.close()
        print("Fetched Theaters:", theaters)  # Debugging: Print data in the console
        return render_template('viewtheater_user.html', theaters=theaters)
    except Exception as e:
        print("Error Fetching Data:", e)
        return "Error loading theaters."
    
@app.route('/view_mall_user')
def view_mall_user():
    try:
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM malls")
        malls = cur.fetchall()
        cur.close()
        print("Fetched Malls:", malls)  # Debugging: Print data in the console
        return render_template('viewmall_user.html', malls=malls)
    except Exception as e:
        print("Error Fetching Data:", e)
        return "Error loading malls."

@app.route('/view_school_user')
def view_school_user():
    try:
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM schools")
        schools = cur.fetchall()
        cur.close()
        print("Fetched Schools:", schools)  # Debugging: Print data in the console
        return render_template('viewschool_user.html', schools=schools)
    except Exception as e:
        print("Error Fetching Data:", e)
        return "Error loading schools."

@app.route('/view_college_user')
def view_college_user():
    try:
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM colleges")
        colleges = cur.fetchall()
        cur.close()
        print("Fetched Schools:", colleges)  # Debugging: Print data in the console
        return render_template('viewcollege_user.html', colleges=colleges)
    except Exception as e:
        print("Error Fetching Data:", e)
        return "Error loading colleges."


@app.route('/manage_users')
def manage_users():
    """ Fetch all users from the database and display them. """
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT id, name, email FROM users")
    users = cursor.fetchall()  # Returns a list of dictionaries
    cursor.close()

    if not users:
        users = []  # Ensure it's always a list

    return render_template('manage_users.html', users=users)

@app.route('/view_user/<int:user_id>')
def view_user(user_id):
    """ Display user details based on user_id. """
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT id, name, email FROM users WHERE id = %s", (user_id,))
    user = cursor.fetchone()
    cursor.close()

    if user:
        return f"Viewing user: {user['name']} ({user['email']})"
    return "User not found", 404

@app.route('/edit_user/<int:user_id>', methods=['GET', 'POST'])
def edit_user(user_id):
    """ Edit a user's details. """
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT id, name, email FROM users WHERE id = %s", (user_id,))
    user = cursor.fetchone()

    if not user:
        cursor.close()
        return "User not found", 404

    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        
        cursor.execute("UPDATE users SET name = %s, email = %s WHERE id = %s", (name, email, user_id))
        mysql.connection.commit()
        cursor.close()
        return redirect(url_for('manage_users'))

    cursor.close()
    return render_template('edit_user.html', user=user)

@app.route('/delete_user/<int:user_id>', methods=['POST'])
def delete_user(user_id):
    """ Delete a user from the database. """
    cursor = mysql.connection.cursor()
    cursor.execute("DELETE FROM users WHERE id = %s", (user_id,))
    mysql.connection.commit()
    cursor.close()
    
    return redirect(url_for('manage_users'))

@app.route('/view_report')
def view_report():
    # 🔹 Make session permanent so user doesn't get logged out unexpectedly
    session.permanent = True

    # 🔹 Check if user is logged in
    if 'user_id' not in session:
        flash('Please log in first', 'danger')
        return redirect(url_for('login'))

    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')

    try:
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)

        query = "SELECT * FROM reports"
        params = []

        if start_date and end_date:
            query += " WHERE timestamp BETWEEN %s AND %s"
            params = [start_date, end_date]

        cursor.execute(query, params)
        reports = cursor.fetchall()

        cursor.close()
        connection.close()

        # 🔹 Ensure session stays active
        session.modified = True

        # 🔹 Data processing for charts
        user_counts = Counter(report['user'] for report in reports)
        user_names = list(user_counts.keys())
        user_actions = list(user_counts.values())

        date_counts = Counter(report['timestamp'].strftime('%Y-%m-%d') for report in reports)
        action_dates = list(date_counts.keys())
        date_values = list(date_counts.values())

        return render_template(
            'view_report.html',
            reports=reports,
            user_names=user_names,
            user_actions=user_actions,
            action_dates=action_dates,
            date_counts=date_values
        )

    except mysql.connector.Error as err:
        flash(f"Database error: {err}", "danger")
        return redirect(url_for('admin_dashboard'))


if __name__ == "__main__":
    app.run(debug=True)
